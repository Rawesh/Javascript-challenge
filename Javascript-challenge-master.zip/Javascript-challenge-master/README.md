# Javascript-challenge
Voorbeeld applicatie : https://tweedekamer2017.stemwijzer.nl/#intro
